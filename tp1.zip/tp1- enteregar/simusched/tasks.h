#ifndef __TASKS_H__
#define __TASKS_H__

#include "basetask.h"
#include <stdlib.h> //rand
void tasks_init(void);

#endif
